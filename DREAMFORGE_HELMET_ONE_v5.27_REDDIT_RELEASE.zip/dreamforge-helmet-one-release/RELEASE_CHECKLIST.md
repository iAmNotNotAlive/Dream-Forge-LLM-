# Public release checklist

- [x] Include setup and test instructions.
- [x] State the exact test suite and result run during release preparation.
- [x] Clearly distinguish demo mode from model-backed responses.
- [x] Warn that the web preview's memory ledger is shared/public.
- [x] Warn that production security and web endpoint testing remain incomplete.
- [x] Include a copy-ready Reddit post draft.
- [ ] Choose a license if reuse/redistribution is intended.
- [ ] If hosting publicly, add authentication or remove public memory exposure, rate limits, abuse controls, spending limits, and persistent storage only if needed.
- [ ] Perform an independent security review before inviting unrestricted public traffic.
