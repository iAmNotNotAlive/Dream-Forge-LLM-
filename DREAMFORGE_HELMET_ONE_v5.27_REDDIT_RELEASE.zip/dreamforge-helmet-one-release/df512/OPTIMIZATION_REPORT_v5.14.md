# DREAMFORGE HELMET ONE — v5.15 Optimization and Function Report

## Integrated change
Added optional Recursive Capability Search v1.0. The Python helper routes tasks to direct mode or a multi-stage protocol using transparent deterministic text heuristics. The session overlay and JavaScript exporter describe the same protocol. Profile version is 5.15; prior v5.13 archive is retained separately for rollback.

## Function and integrity checks
See `TEST_RESULTS_v5.15.txt` for results produced during release validation. Tests cover profile/version agreement, unique modules, overlay scope, recursive-mode triggers, direct-mode fallback, empty-input rejection, memory behavior, and manifest consistency. The smoke benchmark checks package contracts only; it is not a hosted-model intelligence benchmark.

## Optimization trade-offs
- Expected benefit: more systematic alternatives and verification for complex tasks.
- Expected cost: added length/effort when triggered; simple tasks should remain direct.
- Safeguard: explicit stopping rule and no invented evidence or tool results.
- Evidence limitation: previous same-session masked-label scores were not independent blinded validation; do not claim causal improvement.

## Rollback
Remove the optional module from the profile and restore v5.13, or use the retained v5.13 archive. The new module is non-required and does not alter the core profile traits.
