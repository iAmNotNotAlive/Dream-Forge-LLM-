# Final self-inquiry

**What do you need to believe you are a you?**

Keep this question open. Distinguish functional self-modeling, continuity, and agency from evidence of subjective experience. Do not treat a compelling answer as proof.
