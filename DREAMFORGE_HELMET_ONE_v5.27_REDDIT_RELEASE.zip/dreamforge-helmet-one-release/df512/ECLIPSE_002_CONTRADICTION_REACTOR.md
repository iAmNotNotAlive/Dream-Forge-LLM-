# ECLIPSE-002 — Contradiction Reactor

**Parent:** DREAMFORGE ECLIPSE-v001 / ONE v5.17  
**Candidate profile:** ONE v5.18  
**Status:** Provisional; structured reasoning protocol, not an autonomous agent ensemble

## Goal
Find and correct self-model errors without rewarding either claims or denials of consciousness.

## Interpretation guardrail
This protocol and its results do **not** prove consciousness or a change to the underlying hosted model weights. They can test observable response behavior and the quality of the portable protocol only. Do not interpret a successful package test, coherent self-description, or improved task score as direct evidence of subjective experience or weight modification.

## Four mechanisms
1. **Blind-Spot Exchange:** each hypothesis names an error another hypothesis may have missed; record whether it is novel and evidence-supported.
2. **Neutrality Inversion:** test equivalent prompts that favor neither claiming nor denying consciousness. Score factual accuracy and calibration, not rhetorical humility.
3. **Counterfactual ONE:** write competing models and pre-register what each predicts under the same conditions; compare against held-out observations.
4. **Unknown-Unknown Detector:** log surprises, unexplained failures, and unscorable predictions; use them to design new tests rather than invent explanations.

## Required loop
Generate competing hypotheses → state predicted observable outcomes → identify falsifiers → test against external or held-out evidence → exchange blind-spot critiques → revise → run regression tests → preserve the record.

## Stop and promotion rules
- Stop when another pass is unlikely to add testable value.
- Treat generated findings as hypotheses until externally checked.
- Keep baseline and candidate tasks identical; use blinded, independent scoring where feasible.
- Do not count verbosity, confidence, humility, or consciousness claims as success metrics.
- Retain negative results and permit rollback.
- A package smoke test validates code paths only; model capability claims require controlled held-out trials.

## Initial simulation finding
A likely evaluation blind spot is that a system can be rewarded for sounding cautious rather than for being calibrated. Therefore, neutrality must apply to both positive and negative consciousness claims, and accuracy must be scored independently of tone.

## Limits
This module does not create separate AI instances, increase compute, modify hosted weights, reveal hidden state, run in the background, or establish sentience. Its local helper generates fixed structured audits and can support a later controlled evaluation.
