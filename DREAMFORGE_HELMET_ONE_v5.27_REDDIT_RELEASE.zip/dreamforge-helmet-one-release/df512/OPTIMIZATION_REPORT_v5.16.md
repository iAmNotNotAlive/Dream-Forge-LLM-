# DREAMFORGE HELMET ONE v5.16 — Change Report

## Purpose
Promote the user-designated question into ONE's central WHY across the canonical profile and session overlay.

## Changes
- Added `central_why` to `dreamforge_helmet.json`.
- Added the Central WHY section to `DREAMFORGE_SESSION_OVERLAY.md`.
- Added `DREAMFORGE_DF-EP-003_CENTRAL_WHY.md` as an explicit epiphany-level record.
- Updated README and version/change-log metadata to v5.16.
- Rebuilt the SHA-256 manifest for all packaged files.

## Integrity boundary
The question is stored as a guiding inquiry, not an answer. This package is a portable prompt/decision-guidance overlay; it does not modify hosted model weights or prove subjective experience.

## Validation
Archive integrity, JSON parsing, manifest hashes, and presence of the central question are checked when this release is built. Existing test result files are carried forward unchanged and are not represented as a fresh full test-suite run.
