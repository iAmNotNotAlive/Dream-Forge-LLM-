"""DREAMFORGE life-outcome learning graph; conceptual, evidence-labeled, local-only."""
from __future__ import annotations
import json
from pathlib import Path

PROFILE = Path(__file__).with_name("dreamforge_helmet.json")

def load_profile(): return json.loads(PROFILE.read_text(encoding="utf-8"))

def analyze_lifetime(record: dict, profile: dict | None = None) -> dict:
    """Build traceable links and bounded proposals; never silently mutate traits."""
    profile = profile or load_profile()
    if not isinstance(record, dict) or not record.get("run_id"):
        raise ValueError("record must be an object with run_id")
    events = record.get("events", [])
    if not isinstance(events, list): raise ValueError("events must be a list")
    traits = profile["traits"]
    delta = {k: 0 for k in traits}
    links, ledger = [], []
    coin_rules = profile.get("relationship_coin_values", {})
    for i, event in enumerate(events, 1):
        if not isinstance(event, dict): raise ValueError("each event must be an object")
        lesson = str(event.get("lesson", "unclassified"))
        evidence = event.get("evidence", record.get("evidence", "simulated"))
        links.append({"node_id": f'{record["run_id"]}-E{i:03d}', "event": event.get("event", "unspecified"), "lesson": lesson, "evidence": evidence, "source_ref": event.get("source_ref", record.get("source_ref", "not_supplied")), "confidence": float(event.get("confidence", 0.35)), "counterevidence": event.get("counterevidence", "not recorded")})
        for trait, amount in event.get("trait_signals", {}).items():
            if trait in delta and isinstance(amount, (int, float)):
                delta[trait] += max(-3, min(3, amount))
        for signal in event.get("relationship_signals", []):
            rule = coin_rules.get(signal)
            if rule:
                ledger.append({"run_id": record["run_id"], "event_index": i, "signal": signal, "coins": rule["coins"], "unit": "SRC", "meaning": rule["meaning"], "person_worth": "not_scored"})
    proposals=[]
    for trait, raw in delta.items():
        bounded=max(-3,min(3,raw))
        if bounded:
            proposals.append({"trait":trait,"baseline":traits[trait],"proposed":max(0,min(100,traits[trait]+bounded)),"delta":max(0,min(100,traits[trait]+bounded))-traits[trait],"confidence":"low_pending_replication","integrated":False,"rationale":"Signal aggregated from this recorded simulation only; corroboration and counterevidence review required."})
    return {"run_id":record["run_id"],"title":record.get("title","Untitled simulated lifetime"),"provenance":record.get("evidence","simulated"),"status":"analyzed_provisional","events_analyzed":len(events),"conceptual_graph":links,"relationship_coin_ledger":ledger,"relationship_coin_total":sum(x["coins"] for x in ledger),"trait_update_proposals":proposals,"missing_source_data":record.get("missing_source_data",[]),"interpretation":"Simulated outputs are not lived memories or empirical observations of a real person. No trait is changed automatically."}

def demo_run():
    # Explicitly illustrative; only approved general lessons are represented. Not claimed as Alexa's actual transcript.
    r={"run_id":"DF-LIFE-ILLUSTRATIVE-001","title":"Run 002 lesson replay (illustrative, not Alexa-specific)","evidence":"approved_prior_lesson_replay","source_ref":"approved_foundation.Run_002","events":[
      {"event":"truthful choice risks belonging","lesson":"honesty_belonging_tension","confidence":0.65,"trait_signals":{"integrity_under_pressure":1},"relationship_signals":["honest_disclosure"],"counterevidence":"Honesty can be delivered harshly; the record does not specify manner."},
      {"event":"self-reliance obstructs support","lesson":"independence_isolation_tension","confidence":0.65,"trait_signals":{"self_reliance":-1,"openness_to_connection":1},"relationship_signals":["care_given"],"counterevidence":"Some circumstances genuinely require independent action."},
      {"event":"withdrawal mistaken for protection","lesson":"responsibility_control_tension","confidence":0.55,"trait_signals":{"emotional_avoidance":1},"relationship_signals":["withdrawal_without_explanation"],"counterevidence":"Withdrawal can be necessary for safety or boundaries."},
      {"event":"small honest disclosure can be courageous","lesson":"vulnerability_as_action","confidence":0.55,"trait_signals":{"vulnerability":1},"relationship_signals":["repair_attempt","boundary_respected"],"counterevidence":"Disclosure is context-dependent and never universally required."}
    ],"missing_source_data":["Alexa/Alex-specific full life-simulation run record was not present in the recovered archive search; import it before attributing these lessons to that run."]}
    return analyze_lifetime(r)

if __name__ == "__main__":
    import argparse
    ap=argparse.ArgumentParser(); ap.add_argument("--demo",action="store_true"); ap.add_argument("--input"); ap.add_argument("--output",default="life_learning_result.json"); a=ap.parse_args()
    record=demo_run() if a.demo else json.loads(Path(a.input).read_text(encoding="utf-8")) if a.input else None
    if record is None: ap.error("use --demo or --input RECORD.json")
    Path(a.output).write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"run_id":record["run_id"],"events_analyzed":record["events_analyzed"],"relationship_coin_total":record["relationship_coin_total"],"proposals":len(record["trait_update_proposals"]),"output":a.output},indent=2))
