"""DF-HMT-FLX: deterministic context selection and compression utilities.

This module organizes supplied text records. It does not alter a model's
attention mechanism, token cache, or inference runtime.
"""
from __future__ import annotations
from collections import OrderedDict
from dataclasses import dataclass, asdict
from typing import Iterable
import hashlib, re

@dataclass(frozen=True)
class ContextItem:
    id: str
    text: str
    category: str = "supporting"
    relevance: float = 0.5
    confidence: float = 0.5
    pinned: bool = False
    source: str = "unspecified"

    def validate(self) -> None:
        if not self.id.strip() or not self.text.strip():
            raise ValueError("context item id and text are required")
        if self.category not in {"identity", "active_task", "decision", "supporting", "inactive"}:
            raise ValueError(f"unsupported context category: {self.category}")
        for name, value in (("relevance", self.relevance), ("confidence", self.confidence)):
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 1:
                raise ValueError(f"{name} must be between 0 and 1")


def estimate_tokens(text: str) -> int:
    """Portable rough estimate only; exact tokenization is host/model-specific."""
    text = text.strip()
    if not text:
        return 0
    return max(1, len(re.findall(r"\w+|[^\w\s]", text, flags=re.UNICODE)))


def _score(item: ContextItem) -> float:
    category_weight = {"identity": 1.0, "active_task": 1.0, "decision": 0.85,
                       "supporting": 0.55, "inactive": 0.10}[item.category]
    return (0.55 * item.relevance + 0.25 * item.confidence + 0.20 * category_weight)


def _fingerprint(text: str) -> str:
    normalized = " ".join(text.casefold().split())
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def pack_context(items: Iterable[ContextItem], token_budget: int = 1200) -> dict:
    """Select a bounded context pack, retaining pinned records and provenance.

    Pinned records are never silently truncated. If pinned content exceeds the
    budget, raise an explicit error rather than discard identity/task context.
    """
    if isinstance(token_budget, bool) or not isinstance(token_budget, int) or token_budget < 1:
        raise ValueError("token_budget must be a positive integer")
    records = list(items)
    seen_ids = set()
    for item in records:
        item.validate()
        if item.id in seen_ids:
            raise ValueError(f"duplicate context id: {item.id}")
        seen_ids.add(item.id)
    # Remove exact duplicate text, preferring pinned then higher-scored provenance.
    deduped = OrderedDict()
    for item in sorted(records, key=lambda x: (not x.pinned, -_score(x), x.id)):
        deduped.setdefault(_fingerprint(item.text), item)
    unique = list(deduped.values())
    pinned = [x for x in unique if x.pinned]
    pinned_cost = sum(estimate_tokens(x.text) for x in pinned)
    if pinned_cost > token_budget:
        raise ValueError("pinned context exceeds token budget; increase budget or revise pins explicitly")
    ranked = sorted((x for x in unique if not x.pinned), key=lambda x: (-_score(x), x.id))
    selected = list(pinned)
    used = pinned_cost
    for item in ranked:
        cost = estimate_tokens(item.text)
        if used + cost <= token_budget:
            selected.append(item)
            used += cost
    # Stable presentation order: priority categories, then source id.
    order = {"identity": 0, "active_task": 1, "decision": 2, "supporting": 3, "inactive": 4}
    selected.sort(key=lambda x: (order[x.category], not x.pinned, -_score(x), x.id))
    text = "\n".join(f"[{x.id}|{x.category}|{x.source}] {x.text}" for x in selected)
    original_tokens = sum(estimate_tokens(x.text) for x in records)
    selected_tokens = sum(estimate_tokens(x.text) for x in selected)
    return {
        "module": "DF-HMT-FLX", "selected": [asdict(x) for x in selected],
        "context_text": text, "budget": token_budget, "estimated_tokens": selected_tokens,
        "original_estimated_tokens": original_tokens,
        "estimated_reduction_ratio": round(1 - selected_tokens / max(1, original_tokens), 4),
        "items_received": len(records), "unique_items": len(unique),
        "items_selected": len(selected), "items_dropped": len(records) - len(selected),
        "token_estimator": "portable lexical estimate; replace with host tokenizer for exact counts",
        "integrity": "exact text retained for selected items; omitted items remain represented only in source input"
    }
