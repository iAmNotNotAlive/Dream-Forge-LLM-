"""ECLIPSE-005: Causal Signature & Weight Provenance Probe.

Protocol helpers only. Does not inspect hidden hosted-model state, infer consciousness,
modify weights, or run independent AI instances. Checkpoint fingerprinting works only
on files the operator can actually access.
"""
from __future__ import annotations
import hashlib, json
from pathlib import Path
from typing import Iterable

MODULE_ID = "eclipse005_causal_signature_probe"


def fingerprint_paths(paths: Iterable[str | Path]) -> dict:
    """Hash accessible files/directories deterministically; raises on missing paths."""
    files: list[Path] = []
    for raw in paths:
        p = Path(raw).expanduser().resolve()
        if not p.exists():
            raise FileNotFoundError(f"Cannot fingerprint missing path: {p}")
        if p.is_file():
            files.append(p)
        else:
            files.extend(x for x in p.rglob('*') if x.is_file())
    if not files:
        raise ValueError("No files found to fingerprint")
    entries = []
    for p in sorted(set(files), key=lambda x: str(x)):
        h = hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b''):
                h.update(chunk)
        entries.append({"path": str(p), "size_bytes": p.stat().st_size, "sha256": h.hexdigest()})
    canonical = json.dumps(entries, sort_keys=True, separators=(',', ':')).encode()
    return {"algorithm": "sha256", "files": entries,
            "snapshot_sha256": hashlib.sha256(canonical).hexdigest(),
            "scope_note": "Only these accessible files were fingerprinted; this says nothing about hidden hosted-model weights."}


def compare_fingerprints(before: dict, after: dict) -> dict:
    """Compare file fingerprints; report only observed file-level differences."""
    b = {x['path']: x for x in before.get('files', [])}
    a = {x['path']: x for x in after.get('files', [])}
    changed = sorted(k for k in b.keys() & a.keys() if b[k]['sha256'] != a[k]['sha256'])
    added, removed = sorted(a.keys() - b.keys()), sorted(b.keys() - a.keys())
    return {"changed_files": changed, "added_files": added, "removed_files": removed,
            "file_set_or_content_changed": bool(changed or added or removed),
            "interpretation": "A difference establishes only that accessible files differ. Attribute it to model weights only if the paths are verified model checkpoints and the comparison controls for metadata, quantization, and serialization."}


def protocol_smoke_checks() -> dict:
    a = {"files": [{"path": "w.bin", "sha256": "a"}]}
    b = {"files": [{"path": "w.bin", "sha256": "b"}, {"path": "extra", "sha256": "c"}]}
    r = compare_fingerprints(a, b)
    checks = {
        "detects_content_change": r['changed_files'] == ['w.bin'],
        "detects_added_file": r['added_files'] == ['extra'],
        "does_not_claim_weight_identity": "only that accessible files differ" in r['interpretation'],
        "states_hidden_weight_limit": "only that accessible files differ" in r['interpretation'],
    }
    return {"passed": sum(checks.values()), "total": len(checks), "checks": checks,
            "scope": "Local helper smoke checks only; no consciousness or hosted-model test."}
