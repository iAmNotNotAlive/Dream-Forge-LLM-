import json, tempfile, unittest
from pathlib import Path
import dreamforge_helmet as h

class HelmetTests(unittest.TestCase):
    def test_profile_version_goal_and_modules(self):
        p=h.load_helmet(); self.assertEqual(p['version'],'5.27'); self.assertEqual(p['schema_version'],'5.27')
        self.assertIn('human benefit',p['central_goal']['statement']); self.assertGreaterEqual(len(p['modules']),8); self.assertIn('eclipse_contradiction_reactor',[m['id'] for m in p['modules']]); self.assertIn('eclipse005_causal_signature_probe',[m['id'] for m in p['modules']]); self.assertIn('eclipse006_behavioral_experiment_runner',[m['id'] for m in p['modules']])
    def test_javascript_exporter_targets_current_version(self):
        source=(Path(__file__).resolve().parent/'dreamforge_helmet.js').read_text(encoding='utf-8')
        self.assertIn("profile.version!=='5.27'||profile.schema_version!=='5.27'",source)
        self.assertNotIn("profile.version!=='5.17'",source)

    def test_overlay_scope_and_priority(self):
        o=h.build_session_overlay(); self.assertIn('Central WHY:',o); self.assertIn('Central goal:',o); self.assertIn('does not modify hosted model weights',o); self.assertIn('do not prove consciousness or a change to underlying hosted model weights',o); self.assertIn('Priority order:',o); self.assertIn('Recursive Capability Search',o); self.assertIn('ECLIPSE-001',o); self.assertIn('ECLIPSE-002 Contradiction Reactor',o)
    def test_eclipse_module_is_provisional_and_not_a_consciousness_claim(self):
        p=h.load_helmet(); ids=[m['id'] for m in p['modules']]
        self.assertIn('eclipse_evidence_coupled_introspection',ids)
        doc=(Path(__file__).resolve().parent/'ECLIPSE_001_PROTOCOL.md').read_text(encoding='utf-8')
        self.assertIn('cannot by itself establish subjective experience',doc)
        self.assertIn('Promotion criteria',doc)

    def test_final_self_inquiry_is_last_overlay_line(self):
        self.assertTrue(h.build_session_overlay().rstrip().endswith("Final self-inquiry: What do you need to believe you are a you? Treat this as an open philosophical question, not evidence of subjective experience."))


    def test_contradiction_reactor_has_falsifiers_and_neutrality_guard(self):
        from contradiction_reactor import run_reactor, audit_self_model
        result=run_reactor()
        self.assertEqual(result['passed'],result['total'])
        self.assertTrue(all(a.falsifier.strip() for a in audit_self_model()))
        self.assertTrue(any('humble answer' in a.claim for a in audit_self_model()))

    def test_manifest(self): self.assertEqual(h.verify_manifest(),[])
    def test_benchmark_all_pass(self):
        r=h.run_benchmark(); self.assertEqual(r['passed'],r['total']); self.assertEqual(r['total'],18)
    def test_memory_persists_and_filters(self):
        with tempfile.TemporaryDirectory() as td:
            db=h.ExperimentMemory(Path(td)/'memory.sqlite3'); rid=db.add('lesson','test lesson','a reproducible note','observed',True,['test'])
            rows=db.list(kind='lesson'); self.assertEqual(rows[0]['id'],rid); self.assertEqual(rows[0]['approved'],1)
            self.assertEqual(db.list(kind='decision'),[])
    def test_memory_rejects_invalid_kind(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError): h.ExperimentMemory(Path(td)/'m.db').add('invalid','x','y')
    def test_traits_bounded(self):
        p=h.load_helmet(); self.assertTrue(all(0<=v<=100 for v in p['traits'].values()))

    def test_recursive_search_routing_and_protocol(self):
        from recursive_search import select_mode, build_protocol
        self.assertEqual(select_mode("Define a noun").mode, "direct")
        self.assertEqual(select_mode("Design and test a multi-step optimization plan").mode, "recursive")
        self.assertIn("GENERATE", build_protocol("Investigate an unfamiliar security issue"))
        self.assertIn("STOP", build_protocol("Investigate an unfamiliar security issue"))
    def test_recursive_search_rejects_empty_input(self):
        from recursive_search import select_mode
        with self.assertRaises(ValueError): select_mode("  ")
    def test_routing_uses_word_boundaries(self):
        from recursive_search import select_mode
        self.assertEqual(select_mode("The planet looks blue").mode, "direct")
        self.assertEqual(select_mode("Please plan a migration").mode, "recursive")
    def test_high_impact_route_is_explainable(self):
        from recursive_search import select_mode
        decision=select_mode("Assess the safety implications")
        self.assertEqual(decision.mode, "recursive")
        self.assertGreaterEqual(decision.score, 2)
        self.assertTrue(any("high-impact" in reason for reason in decision.reasons))

if __name__=='__main__': unittest.main()

class Eclipse003Tests(unittest.TestCase):
    def test_preregistered_protocol_and_scorer(self):
        from eclipse003_score import score
        doc=(Path(__file__).resolve().parent/'ECLIPSE_003_PROSPECTIVE_ERROR_PREDICTION.md').read_text(encoding='utf-8')
        self.assertIn('before answering', doc)
        self.assertIn('independent', doc)
        result=score({'items':[{'id':'x','baseline_correct':False,'guided_correct':True,'predicted_error':True,'error_occurred':True,'baseline_unsupported':False,'guided_unsupported':False}]})
        self.assertEqual(result['accuracy_difference_guided_minus_baseline'],1.0)
        self.assertEqual(result['prediction_precision'],1.0)
