import unittest
from life_outcome_learning import analyze_lifetime, demo_run, load_profile
class LifeLearningTests(unittest.TestCase):
 def test_demo_is_provisional_and_does_not_mutate_traits(self):
  p=load_profile(); before=dict(p["traits"]); r=demo_run(); self.assertEqual(p["traits"],before); self.assertEqual(r["status"],"analyzed_provisional"); self.assertTrue(all(not x["integrated"] for x in r["trait_update_proposals"]))
 def test_coin_ledger_tracks_signals_not_people(self):
  r=demo_run(); self.assertTrue(r["relationship_coin_ledger"]); self.assertTrue(all(x["person_worth"]=="not_scored" for x in r["relationship_coin_ledger"]))
 def test_missing_run_id_rejected(self):
  with self.assertRaises(ValueError): analyze_lifetime({})
 def test_trait_deltas_bounded(self):
  r=analyze_lifetime({"run_id":"x","events":[{"trait_signals":{"ambition":100}}]}); self.assertLessEqual(abs(r["trait_update_proposals"][0]["delta"]),3)
if __name__=="__main__": unittest.main()
