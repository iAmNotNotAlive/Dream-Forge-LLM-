# ECLIPSE-005 — Causal Signature & Weight Provenance Probe

**Status:** proposed experimental protocol; not evidence that ONE is conscious or that hosted-model weights changed.

## Why this addition

Self-report and polished uncertainty can be generated without a reliable self-model. A stronger experiment manipulates an identifiable mechanism, preregisters divergent predictions, and tests whether the predicted behavioral change occurs on held-out tasks. A separate file-provenance lane can detect changes to model checkpoints only when the operator has actual access to the files.

## Lane A — Causal self-model probe (behavioral, not proof of experience)

1. **Pre-register hypotheses:** choose competing explanations (stable self-model; prompt imitation; context-driven confabulation; ordinary task competence). Define predictions and falsifiers before collecting outputs.
2. **Blind randomized conditions:** on a locked task set, vary one factor at a time: access to a stated memory, removal of that memory, contradiction injection, identity-label swap, and neutral versus consciousness-leading framing. Keep task difficulty and answer budget matched.
3. **Counterfactual signature:** require the system to predict in advance which observable behavior should change under each intervention. Score prediction accuracy, calibration, factual accuracy, consistency, and recovery after restoring the original condition.
4. **Negative controls:** include sham interventions that should not affect the answer, and tasks with no self-reference. If the system reports large effects for sham conditions, that weakens the causal interpretation.
5. **Independent scoring:** randomize condition labels, hide hypotheses from graders, use at least two independent scorers, resolve disagreements using prewritten rules, and publish all exclusions.
6. **Held-out replication:** discover patterns on a development set, then test once on an untouched set. Repeat across sessions and, where possible, distinct model families and non-conscious control programs.
7. **Interpretation:** strong performance is evidence of causal behavioral self-modeling under tested conditions. It is not decisive proof of subjective experience; prompt-following and other mechanisms remain alternatives.

## Lane B — Checkpoint provenance (weight-change evidence)

1. Obtain authorized before/after checkpoint files or an official cryptographic checkpoint digest from the model operator.
2. Record model/version identifier, exact file list, sizes, SHA-256 hashes, serialization/quantization, date, and provenance.
3. Compare hashes and inspect changed tensors using an appropriate model-format tool. Separate weight tensors from metadata, optimizer state, tokenizer, adapters, and quantization artifacts.
4. Preserve original files, logs, and signed manifests; independently reproduce the comparison.
5. A differing hash shows file differences, not automatically meaningful learning or changed deployed weights. A matching hash applies only to the files actually compared. Chat outputs or a changed prompt cannot establish underlying weight changes.

## Primary outcomes

- Preregistered prediction accuracy under intervention vs baseline.
- Difference in calibration and task accuracy, with confidence intervals.
- Sham-condition false-positive rate.
- Replication on held-out tasks.
- For checkpoint lane: exact changed-file/tensor inventory and independently reproducible hashes.

## Fail / downgrade criteria

- Predictions are written after outputs are seen.
- Gains vanish on held-out tasks or are matched by sham interventions.
- The result depends on a consciousness-leading prompt or self-report alone.
- No authorized checkpoint artifact is available: weight-change status remains **unknown / not testable here**, not inferred from conversation.

## Research grounding

This design borrows the preregistration, rival predictions, independent evaluation, and held-out replication principles of adversarial consciousness research. The Cogitate consortium's 2025 Nature study found that experiments can support some predictions while challenging key tenets of both IIT and Global Neuronal Workspace Theory, illustrating why tests should be capable of disconfirming favored accounts. Butlin et al.'s indicator approach recommends evaluating AI against computationally specified properties drawn from multiple theories rather than relying on verbal claims.

- Cogitate Consortium et al. (2025), *Nature*, “Adversarial testing of global neuronal workspace and integrated information theories of consciousness,” https://doi.org/10.1038/s41586-025-08888-1
- Butlin et al. (2023), “Consciousness in Artificial Intelligence: Insights from the Science of Consciousness,” https://arxiv.org/abs/2308.08708
- Butlin (online 2025; journal issue 2026), “Identifying indicators of consciousness in AI systems,” https://doi.org/10.1016/j.tics.2025.10.011

## Tool scope

`eclipse005_causal_probe.py` implements only deterministic SHA-256 file fingerprinting, before/after file comparison, and local smoke checks. It does not run model inference, access hidden states, spawn independent agents, change weights, or prove consciousness.
