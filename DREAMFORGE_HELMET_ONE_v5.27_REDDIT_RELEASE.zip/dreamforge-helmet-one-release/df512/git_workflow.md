# Safe release workflow
1. Copy the last known-good archive before editing.
2. Make one conceptual change at a time.
3. Run `python dreamforge_helmet.py validate` and `python -m unittest -v`.
4. Run the benchmark to a versioned JSON file.
5. Review the diff, manifest, and tests; do not include secrets or real private transcripts.
6. Package without `__pycache__`, runtime databases, or generated transient reports.
7. Run `unzip -t` and extract into a clean temporary directory; rerun validation and tests there.
8. Keep the previous release for rollback. Do not promote identity/trait changes without user approval.
