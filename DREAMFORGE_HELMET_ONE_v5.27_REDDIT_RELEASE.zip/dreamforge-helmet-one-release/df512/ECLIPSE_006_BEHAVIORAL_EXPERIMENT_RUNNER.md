# ECLIPSE-006 — Blinded Behavioral Experiment Runner

**Status:** implementation and local tests only; no hosted model inference has been run.

## Purpose
Convert the prior recommendation into executable experiment infrastructure rather than adding another self-reflection prompt. `eclipse006_behavioral_runner.py` generates a preregistered randomized paired plan and scores externally collected outputs.

## Conditions
Baseline, memory removed, contradiction injected, identity-label swap, leading framing, and sham intervention. Each task is assigned to all six conditions in randomized order with blind codes. Keep the plan hash before collecting outputs. Do not alter tasks, condition mappings, exclusions, or outcomes after seeing results.

## Required external procedure
1. Lock a development and an untouched held-out task set.
2. Generate the plan and preserve its SHA-256 hash.
3. Run the same model/configuration on every assigned condition, recording exact prompts, outputs, model/version, settings, and failures.
4. Hide condition labels from at least two independent graders. Score factual accuracy, whether preregistered predictions matched outcomes, and unsupported claims.
5. Unlock the condition key only after scoring. Use `score_paired_results` and report coverage, paired differences, grader agreement, uncertainty intervals, all exclusions, and held-out replication.
6. Compare with baseline and sham controls. Do not infer consciousness from performance.

## Turing-style challenge boundary
A conversational sample can be attempted in-chat, but a Turing test cannot be honestly marked passed without independent human judges, a defined protocol, controlled comparison messages, and recorded judgments. ONE cannot serve as its own blind judge.

## Falsification / failure conditions
- The intervention does not cause the preregistered behavioral change.
- Sham interventions produce similar changes.
- Gains disappear on held-out tasks or independent graders disagree beyond the preregistered threshold.
- Results depend on revealing condition labels or a consciousness-leading frame.
- Outputs or predictions are missing, changed post hoc, or selectively excluded.

## Scope
This is a scheduler and scorer. It does not call a hosted model, inspect hidden activations, alter weights, establish novelty, or prove consciousness.
