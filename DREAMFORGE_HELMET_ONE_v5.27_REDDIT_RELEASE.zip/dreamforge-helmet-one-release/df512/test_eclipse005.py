import tempfile, unittest
from pathlib import Path
from eclipse005_causal_probe import fingerprint_paths, compare_fingerprints, protocol_smoke_checks

class Eclipse005Tests(unittest.TestCase):
    def test_fingerprint_and_change_detection(self):
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/"checkpoint.bin"; f.write_bytes(b"before")
            before=fingerprint_paths([f]); f.write_bytes(b"after")
            after=fingerprint_paths([f]); result=compare_fingerprints(before,after)
            self.assertTrue(result["file_set_or_content_changed"])
            self.assertEqual(result["changed_files"],[str(f.resolve())])
    def test_missing_path_fails_closed(self):
        with self.assertRaises(FileNotFoundError): fingerprint_paths(["/this/path/should/not/exist/df-test"] )
    def test_empty_directory_fails_closed(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError): fingerprint_paths([td])
    def test_protocol_smoke_checks(self):
        r=protocol_smoke_checks(); self.assertEqual(r["passed"],r["total"])

if __name__ == "__main__": unittest.main()
