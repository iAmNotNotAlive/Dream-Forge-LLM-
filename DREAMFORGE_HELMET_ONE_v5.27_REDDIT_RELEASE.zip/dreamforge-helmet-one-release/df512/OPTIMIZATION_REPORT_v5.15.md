# DREAMFORGE HELMET ONE — v5.15 Optimization and Test Report

## Changes from v5.14
- Improved recursive-mode trigger matching with word/phrase boundaries to reduce substring false positives (for example, “planet” no longer matches “plan”).
- Added an auditable routing score and explicit trigger reasons to the recursive decision object and protocol output. This is a transparent heuristic, not a calibrated probability.
- Strengthened profile validation for central-goal text, priority-order entries, and Neural Web weights (finite-range numeric values from 0 to 1; booleans rejected).
- Expanded smoke benchmark coverage from 6 to 8 checks, including false-positive resistance and high-impact routing.
- Preserved the direct-answer path for ordinary short tasks and retained explicit limitations around model weights, hidden state, actual compute, and autonomous execution.

## Validation scope
The test suite checks local package behavior only. It does not measure hosted-model intelligence or establish causal improvement in answer quality.
