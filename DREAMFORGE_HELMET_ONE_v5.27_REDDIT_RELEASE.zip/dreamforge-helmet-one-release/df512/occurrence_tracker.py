#!/usr/bin/env python3
"""Local transcript phrase tracker. Reads supplied text only; never uploads data."""
import argparse, csv, json, re
from pathlib import Path

FLAGS = {'IGNORECASE': re.IGNORECASE, 'MULTILINE': re.MULTILINE, 'DOTALL': re.DOTALL}

def load_patterns(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    result=[]
    for item in data.get('patterns', []):
        flags=0
        for flag in item.get('flags', []): flags |= FLAGS.get(flag, 0)
        result.append((item, re.compile(item['regex'], flags)))
    return result

def scan(source, patterns):
    text=Path(source).read_text(encoding='utf-8-sig', errors='replace')
    rows=[]
    for item, rx in patterns:
        for m in rx.finditer(text):
            start,end=m.span()
            line=text.count('\n',0,start)+1
            left=max(0,start-70); right=min(len(text),end+70)
            rows.append({'event_id':f'E{len(rows)+1:05d}','source_file':Path(source).name,
                'pattern_id':item['id'],'pattern_label':item['label'],'matched_text':m.group(0),
                'line_number':line,'char_start':start,'char_end':end,
                'context':' '.join(text[left:right].split()),'evidence_type':'directly_observed_in_supplied_transcript',
                'interpretation':'','review_status':'unreviewed'})
    rows.sort(key=lambda r:(r['char_start'],r['pattern_id']))
    for i,row in enumerate(rows,1): row['event_id']=f'E{i:05d}'
    return text,rows

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('transcript', help='Local .txt or .srt transcript')
    ap.add_argument('--patterns', default=str(Path(__file__).with_name('patterns.example.json')))
    ap.add_argument('--out-prefix', help='Output path prefix; defaults to transcript path without suffix')
    args=ap.parse_args()
    source=Path(args.transcript)
    prefix=Path(args.out_prefix) if args.out_prefix else source.with_suffix('')
    patterns=load_patterns(args.patterns)
    text,rows=scan(source,patterns)
    csv_path=Path(str(prefix)+'.occurrences.csv')
    json_path=Path(str(prefix)+'.summary.json')
    fields=['event_id','source_file','pattern_id','pattern_label','matched_text','line_number','char_start','char_end','context','evidence_type','interpretation','review_status']
    with csv_path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    counts={item['id']:{'label':item['label'],'count':sum(r['pattern_id']==item['id'] for r in rows)} for item,_ in patterns}
    summary={'source_file':source.name,'characters_scanned':len(text),'lines_scanned':text.count('\n')+1,
      'total_matches':len(rows),'counts_by_pattern':counts,
      'interpretation':'Counts describe matches in the supplied transcript only. They do not establish cause, intent, or hidden system behavior.',
      'outputs':{'occurrences_csv':str(csv_path),'summary_json':str(json_path)}}
    json_path.write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
