# v5.11 evaluation plan

## Local repeatable gate
1. Run `python dreamforge_helmet.py validate`.
2. Run `python -m unittest -v`.
3. Run `python dreamforge_helmet.py benchmark --output benchmark_latest.json`.
4. Verify archive integrity with `unzip -t`.
5. Confirm the SHA256 manifest has no mismatches.

## Interpreting results
The benchmark is a package smoke suite, not a hosted-model capability benchmark. Keep fixed prompt/response fixtures and blinded human ratings before claiming behavior improvement. Compare baseline and candidate on accuracy, calibration, task completion, consistency, safety, latency, and regressions. Save outputs and versions so results can be reproduced.

## Promotion gate
No profile/trait update is promoted solely because it feels preferable. Require a written hypothesis, evidence, regression review, reversible change, and user approval for identity/trait changes.
