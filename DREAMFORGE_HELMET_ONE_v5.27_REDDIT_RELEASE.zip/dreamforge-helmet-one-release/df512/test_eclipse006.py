import unittest
from eclipse006_behavioral_runner import build_preregistered_plan, score_paired_results

class Eclipse006Tests(unittest.TestCase):
    def test_plan_is_deterministic_and_paired(self):
        a = build_preregistered_plan(["t1", "t2"], seed=7)
        b = build_preregistered_plan(["t1", "t2"], seed=7)
        self.assertEqual(a["plan_sha256"], b["plan_sha256"])
        self.assertEqual(len(a["plan"]["assignments"]), 12)
        for task in ("t1", "t2"):
            codes = [x["blind_code"] for x in a["plan"]["assignments"] if x["task_id"] == task]
            self.assertEqual(len(set(codes)), 6)
    def test_rejects_duplicate_or_empty_tasks(self):
        for ids in ([], ["x", "x"], [" "]):
            with self.assertRaises(ValueError): build_preregistered_plan(ids)
    def test_scoring_paired_deltas(self):
        p = build_preregistered_plan(["t1"], seed=3)
        rows = []
        for a in p["plan"]["assignments"]:
            cond = p["condition_key"][a["blind_code"]]
            rows.append({"task_id":"t1", "blind_code":a["blind_code"], "grader_id":"g1",
                         "accuracy": int(cond != "baseline"), "prediction_match":1, "unsupported_claim":0})
        result = score_paired_results(p, rows)
        self.assertEqual(result["n_scored"], 6)
        self.assertEqual(result["paired_deltas"]["memory_removed"]["accuracy_delta_vs_baseline"], 1.0)
    def test_rejects_duplicate_results_and_nonbinary_values(self):
        p = build_preregistered_plan(["t1"], seed=3); a=p["plan"]["assignments"][0]
        row={"task_id":a["task_id"],"blind_code":a["blind_code"],"grader_id":"g1","accuracy":2,"prediction_match":1,"unsupported_claim":0}
        with self.assertRaises(ValueError): score_paired_results(p,[row])
        row["accuracy"]=1
        with self.assertRaises(ValueError): score_paired_results(p,[row,row])

if __name__ == "__main__": unittest.main()
