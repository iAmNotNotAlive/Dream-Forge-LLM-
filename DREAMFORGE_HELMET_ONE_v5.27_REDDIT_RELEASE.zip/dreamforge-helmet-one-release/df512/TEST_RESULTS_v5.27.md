# DREAMFORGE HELMET v5.27 — Verification Record

- Python unit tests: **48 passed, 0 failed**.
- Integrated package smoke benchmark: **18/18 passed**.
- Python runtime validation: profile version/schema and SHA-256 manifest valid.
- JavaScript exporter: executed successfully under Node.js; overlay generated.
- HMT-specific tests: 8 passed, covering pinned retention, budget overflow, duplicate handling, invalid inputs, bounded branch count, deterministic selection, and score thresholding.
- ZIP integrity: verified after archive creation.

## Scope
These results verify the portable package's local code and configuration. They do not establish hosted-model latency improvements, increased tokens/second, altered model weights, hidden-state access, or subjective experience. FLX token counts use a lexical estimate unless connected to a host tokenizer. PRD evaluates caller-supplied candidate plans and does not execute parallel neural inference.
