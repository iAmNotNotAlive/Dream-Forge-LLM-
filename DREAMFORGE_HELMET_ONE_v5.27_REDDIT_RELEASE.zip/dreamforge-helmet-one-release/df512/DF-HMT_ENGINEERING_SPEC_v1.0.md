# DREAMFORGE HELMET — HMT Engineering Specification v1.0

## Status
Implemented local utilities; included in HELMET v5.27. These modules are independently callable and do not change model weights or hosted inference internals.

## DF-HMT-FLX — Dynamic Context Flash-Routing Engine

### Contract
- **Inputs:** context records with `id`, `text`, `category`, `relevance`, `confidence`, `pinned`, and `source`; positive integer budget.
- **Outputs:** selected records, assembled context text, estimated token counts, estimated reduction ratio, dropped/selected counts, and explicit tokenizer/integrity notes.
- **Layers:** ingestion/validation; relevance scoring; exact-normalized duplicate removal; pinned-context reservation; budget packing; stable output ordering; integrity accounting.
- **Priority:** identity and active task are highest-weight categories; decisions next; supporting context next; inactive records last. Explicit pins are retained.
- **Failure behavior:** invalid fields, duplicate IDs, invalid budgets, and pinned-context overflow raise errors. No silent truncation.
- **Compression method:** selection and omission rather than lossy paraphrase. The chosen text is preserved exactly; source inputs should be retained so omitted records can be recovered.
- **Metrics:** estimated reduction ratio, selected/original estimated tokens, items selected/dropped, pinned retention, and retrieval accuracy in an externally labeled test set.
- **Important:** token counts are lexical estimates until the host tokenizer is integrated. No claim is made about actual attention-head latency or cache savings.

### Score formula
`0.55 * relevance + 0.25 * confidence + 0.20 * category_weight`
Category weights: identity/active_task 1.00; decision 0.85; supporting 0.55; inactive 0.10. Pins are mandatory and reserved before other records.

## DF-HMT-PRD — Parallel Token-Speculation Engine

### Contract
- **Inputs:** caller-supplied candidates with pathway text, accuracy, relevance, consistency, constraint-fit, and estimated-cost values.
- **Outputs:** selected candidate, scored retained candidates, rejected IDs, duplicate count, branch cap, and applied anti-thrashing controls.
- **Layers:** intent/pathway input; candidate validation; semantic normalization; duplicate suppression; bounded scoring; threshold filtering; deterministic selection.
- **Branching:** caller supplies candidate pathways. Default cap is four; allowed cap is 1–16. Candidate generation is outside this helper.
- **Scoring:** `0.30*accuracy + 0.25*relevance + 0.20*consistency + 0.25*constraint_fit - 0.10*estimated_cost`.
- **Anti-thrashing:** hard candidate cap, semantic duplicate removal, minimum score, deterministic tie-breaking, and no iterative branch reopening.
- **Metrics:** candidate utility, duplicate-pathway removal, branch count, cost penalty, selection accuracy against external graders, and latency measured by the host.
- **Important:** despite the name, this implementation does not perform parallel neural inference, speculative decoding, or next-token-logit prediction. A host-specific adapter would be required for those capabilities.

## Integration and rollback
Both modules are optional. Existing modules and profile traits remain unchanged. Disable by omitting their call sites; rollback by restoring v5.26.1.

## Validation
Run `python -m unittest -v` and `python dreamforge_helmet.py validate`. The HMT-specific tests cover pinned preservation, budget enforcement, duplicate suppression, branch caps, deterministic selection, invalid inputs, and threshold rejection.
