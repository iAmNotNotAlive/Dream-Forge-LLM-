import json, tempfile, unittest
from pathlib import Path
from feedback_loop import evaluate_and_propose, summarize

class FeedbackLoopTests(unittest.TestCase):
    def test_improvement_is_proposed_not_auto_approved(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'log.jsonl'
            r=evaluate_and_propose(task_id='T1', baseline={'scores':[2,2]}, candidate={'scores':[3,3]}, evidence='simulated', rubric='accuracy', log_path=p)
            self.assertEqual(r['result'],'candidate_better')
            self.assertEqual(r['retention_status'],'pending_human_approval')
            self.assertFalse(r['approved_by_user'])
            self.assertEqual(summarize(p)['trials'],1)
    def test_approved_improvement_can_be_logged(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'log.jsonl'
            r=evaluate_and_propose(task_id='T2', baseline={'scores':[1]}, candidate={'scores':[4]}, evidence='observed', rubric='correctness', approved=True, log_path=p)
            self.assertEqual(r['retention_status'],'approved_for_local_note')
            self.assertEqual(summarize(p)['approved_retention_count'],1)
    def test_no_improvement_not_retained(self):
        with tempfile.TemporaryDirectory() as d:
            r=evaluate_and_propose(task_id='T3', baseline={'scores':[4]}, candidate={'scores':[3]}, evidence='test', rubric='correctness', approved=True, log_path=Path(d)/'l')
            self.assertEqual(r['retention_status'],'not_retained')
    def test_bad_score_rejected(self):
        with self.assertRaises(ValueError):
            evaluate_and_propose(task_id='T4', baseline={'scores':[5]}, candidate={'scores':[3]}, evidence='test', rubric='x', log_path='/tmp/nope')

if __name__ == '__main__': unittest.main()
