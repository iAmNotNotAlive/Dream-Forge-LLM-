# DREAMFORGE HELMET v5.27 — HMT Optimization Report

## Delivered
- DF-HMT-FLX: deterministic context prioritization and budget packing.
- DF-HMT-PRD: bounded candidate-path evaluation and deterministic selection.
- Independent unit tests, integrated smoke cases, updated profile/overlay/exporter, and engineering specification.

## Design decision
FLX uses loss-avoiding selection: it preserves the exact text of retained records and reports omissions, rather than silently paraphrasing source material. PRD uses bounded caller-supplied candidates rather than pretending to run model-internal parallel decoding.

## What is measured
The package can measure local estimated context reduction, pinned-record retention, duplicate removal, candidate count, score ranking, and deterministic selection.

## What is not measured
No hosted-model latency, tokens per second, GPU/TPU utilization, attention-head timing, KV-cache behavior, model-weight changes, or general answer-quality gain is measured by this package. A real runtime adapter and paired held-out evaluation are needed.

## Suggested next improvement
Add a host adapter interface with (1) the actual model tokenizer, (2) context-window/cache telemetry where the runtime exposes it, and (3) paired baseline-versus-FLX/PRD task runs scored independently. This is the highest-value next step because it converts proxy metrics into runtime measurements without conflating package behavior with model compute.
