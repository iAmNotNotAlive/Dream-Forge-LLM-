import unittest
from hmt_flx import ContextItem, pack_context, estimate_tokens
from hmt_prd import Candidate, evaluate_candidates

class HMTFLXTests(unittest.TestCase):
    def test_pinned_and_high_relevance_are_retained(self):
        items=[ContextItem('identity','ONE identity baseline','identity',.8,.9,True,'profile'),
               ContextItem('task','Current task objective','active_task',1,1,True,'user'),
               ContextItem('old','Unrelated old note','inactive',.1,.2,False,'archive')]
        result=pack_context(items, token_budget=30)
        ids={x['id'] for x in result['selected']}
        self.assertIn('identity',ids); self.assertIn('task',ids)
        self.assertLessEqual(result['estimated_tokens'],30)

    def test_duplicate_text_collapses(self):
        result=pack_context([ContextItem('a','same text'),ContextItem('b',' SAME   TEXT ')],100)
        self.assertEqual(result['unique_items'],1)

    def test_pinned_overflow_is_explicit(self):
        with self.assertRaises(ValueError):
            pack_context([ContextItem('p','a very long pinned item',pinned=True)],1)

    def test_invalid_budget(self):
        with self.assertRaises(ValueError): pack_context([],0)

class HMTPRDTests(unittest.TestCase):
    def test_best_path_selected_and_bounded(self):
        candidates=[Candidate('a','direct answer',.9,.9,.9,.9,.1),
                    Candidate('b','deep analysis',.8,.9,.8,.9,.4),
                    Candidate('c','direct   answer',.1,.1,.1,.1,.1)]
        result=evaluate_candidates(candidates,max_candidates=2)
        self.assertEqual(result['selected']['id'],'a')
        self.assertLessEqual(result['candidates_evaluated'],2)
        self.assertEqual(result['duplicate_pathways_removed'],1)

    def test_no_candidate_above_threshold(self):
        result=evaluate_candidates([Candidate('a','path',.1,.1,.1,.1,.9)],min_score=.8)
        self.assertIsNone(result['selected'])

    def test_duplicate_ids_rejected(self):
        c=Candidate('a','path',.5,.5,.5,.5)
        with self.assertRaises(ValueError): evaluate_candidates([c,c])

    def test_invalid_candidate_score_rejected(self):
        with self.assertRaises(ValueError): evaluate_candidates([Candidate('a','path',2,.5,.5,.5)])

if __name__ == '__main__': unittest.main()
