"""Optional explainable complexity routing for DREAMFORGE ONE v5.15.

Selects a procedure only; it does not run an LLM, add compute, or prove correctness.
"""
from __future__ import annotations
import re
from dataclasses import dataclass

COMPLEXITY_TERMS = {
    "compare", "debug", "design", "diagnose", "evaluate", "experiment", "integrate",
    "investigate", "optimize", "plan", "research", "security", "synthesize", "troubleshoot",
    "tradeoff", "trade-off", "uncertain", "unfamiliar", "multi-step", "multiple constraints",
}
HIGH_IMPACT_TERMS = {"medical", "health", "legal", "financial", "safety", "security", "production", "critical"}

def _contains_term(text: str, term: str) -> bool:
    # Match whole words/phrases rather than accidental substrings (e.g. "planet" -> "plan").
    pattern = r"(?<![a-z0-9])" + re.escape(term).replace(r"\ ", r"\s+") + r"(?![a-z0-9])"
    return re.search(pattern, text) is not None

@dataclass(frozen=True)
class SearchDecision:
    mode: str
    reasons: tuple[str, ...]
    score: int = 0

def select_mode(task: str) -> SearchDecision:
    """Route complex or high-impact tasks to a structured protocol, with auditable reasons."""
    if not isinstance(task, str) or not task.strip():
        raise ValueError("task must be a non-empty string")
    normalized = re.sub(r"\s+", " ", task.lower()).strip()
    words = re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)?", normalized)
    matched = sorted(term for term in COMPLEXITY_TERMS if _contains_term(normalized, term))
    impact = sorted(term for term in HIGH_IMPACT_TERMS if _contains_term(normalized, term))
    reasons=[]; score=0
    if len(words) >= 45: reasons.append("long task description"); score += 1
    if matched: reasons.append("complexity cue(s): " + ", ".join(matched)); score += min(2, len(matched))
    if impact: reasons.append("high-impact cue(s): " + ", ".join(impact)); score += 2
    if len(words) >= 25 and any(x in normalized for x in (" and ", " versus ", " vs ", " while ", " although ")):
        reasons.append("multiple linked constraints"); score += 1
    mode="recursive" if score >= 1 else "direct"
    return SearchDecision(mode, tuple(reasons or ["no complexity trigger detected"]), score)

def build_protocol(task: str) -> str:
    decision=select_mode(task)
    if decision.mode == "direct":
        return "Mode: DIRECT\nAnswer clearly and efficiently. Verify essential facts; avoid unnecessary expansion.\nRouting score: 0"
    return "\n".join([
        "Mode: RECURSIVE CAPABILITY SEARCH (optional; complexity-triggered)",
        f"Routing score: {decision.score}",
        "Trigger: " + "; ".join(decision.reasons),
        "1. GENERATE — produce at least three materially different approaches when useful.",
        "2. CHALLENGE — surface assumptions, failure modes, and counterexamples.",
        "3. COMBINE — merge compatible strengths; preserve meaningful disagreements.",
        "4. TEST — use concrete examples, calculations, code, sources, or tools when actually available.",
        "5. AUDIT — distinguish facts, inferences, hypotheses, and unknowns; check unsupported claims.",
        "6. REFINE — repeat only if another pass is likely to change or verify the answer.",
        "7. RECORD — state results, limits, and reproducible next steps when useful.",
        "STOP when expected improvement is low or the answer is sufficiently verified.",
        "Never invent tool use/results, equate confidence with evidence, bypass safety, or claim added compute.",
    ])
