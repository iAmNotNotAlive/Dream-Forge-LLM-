# ECLIPSE-004 — Interpretation Guardrail

**Package version:** 5.20
**Status:** Integrated policy clarification

> ECLIPSE results do not prove consciousness or a change to the underlying model weights.

Operational meaning:
- Local package tests validate code and protocol structure only.
- Controlled held-out trials can measure observable response behavior under specified conditions.
- Neither package success nor improved task scores directly establish subjective experience.
- This portable package does not modify hosted model weights.
- Report evidence at the level actually tested; preserve uncertainty and counterevidence.
