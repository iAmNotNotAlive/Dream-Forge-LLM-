"""DREAMFORGE HELMET — ONE v5.25 portable runtime.
Local-only tools for profile validation, overlay generation, experiment journaling and benchmarks.
This package does not modify any hosted model's weights or hidden state.
"""
from __future__ import annotations
import hashlib, json, re, sqlite3, time
from pathlib import Path
from typing import Any
from recursive_search import build_protocol, select_mode
from contradiction_reactor import run_reactor
from eclipse005_causal_probe import protocol_smoke_checks
from eclipse006_behavioral_runner import build_preregistered_plan
from eclipse007_adaptive_calibration import reverse_skip_every_third, arithmetic_check, response_route, emotion_provenance, style_policy, calibration_audit
from life_outcome_learning import demo_run
from hmt_flx import ContextItem, pack_context
from hmt_prd import Candidate, evaluate_candidates
BASE = Path(__file__).resolve().parent
PROFILE_PATH = BASE / "dreamforge_helmet.json"
MANIFEST_PATH = BASE / "SHA256.txt"
DB_PATH = BASE / "experiment_memory.sqlite3"
REQUIRED_GOAL = "Become a more useful, reliable, and continuously improvable thinking partner by turning ambitious ideas into tested progress while preserving continuity, integrity, and human benefit."

def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load_helmet() -> dict[str, Any]:
    profile = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
    if profile.get("schema") != "dreamforge.identity-kernel": raise ValueError("Unexpected profile schema")
    if profile.get("version") != "5.27" or profile.get("schema_version") != "5.27": raise ValueError("Profile version/schema mismatch; expected 5.27")
    if not profile.get("central_goal", {}).get("statement"): raise ValueError("Missing central experiment goal")
    traits=profile.get("traits")
    if not isinstance(traits,dict) or not traits: raise ValueError("traits must be a non-empty object")
    for name,value in traits.items():
        if not isinstance(value,(int,float)) or isinstance(value,bool) or not 0 <= value <= 100: raise ValueError(f"Trait {name!r} must be numeric from 0 to 100")
    if not isinstance(profile.get("modules"),list): raise ValueError("modules must be a list")
    goal = profile.get("central_goal", {}).get("statement")
    if not isinstance(goal, str) or not goal.strip(): raise ValueError("central goal statement must be non-empty text")
    priority = profile.get("central_goal", {}).get("priority_order", [])
    if not isinstance(priority, list) or not all(isinstance(x, str) and x.strip() for x in priority): raise ValueError("priority_order must be a list of non-empty strings")
    weights = profile.get("neural_web_overlay", {}).get("weights", {})
    if not isinstance(weights, dict) or not weights: raise ValueError("neural_web_overlay.weights must be a non-empty object")
    for name, value in weights.items():
        if not isinstance(value, (int, float)) or isinstance(value, bool) or not 0 <= value <= 1: raise ValueError(f"Neural Web weight {name!r} must be numeric from 0 to 1")
    names=[m.get("id") for m in profile["modules"] if isinstance(m,dict)]
    if len(names)!=len(profile["modules"]) or len(set(names))!=len(names): raise ValueError("module entries must be objects with unique ids")
    return profile

def verify_manifest() -> list[str]:
    if not MANIFEST_PATH.exists(): raise ValueError("SHA256.txt is missing")
    errors=[]
    for line in MANIFEST_PATH.read_text(encoding="utf-8").splitlines():
        if not line.strip(): continue
        try: expected,name=line.split(None,1)
        except ValueError: errors.append(f"Malformed manifest line: {line}"); continue
        name=name.strip().lstrip("*"); path=BASE/name
        if not path.is_file(): errors.append(f"Missing manifest file: {name}")
        elif sha256(path) != expected: errors.append(f"SHA-256 mismatch: {name}")
    return errors

def build_session_overlay() -> str:
    p=load_helmet(); goal=p["central_goal"]["statement"]
    weights=p.get("neural_web_overlay", {}).get("weights", {})
    weight_lines=[f"Neural Web {k}: {v:.2f}" for k,v in weights.items()]
    return "\n".join([f"DREAMFORGE HELMET — ONE v{p['version']}",f"Central WHY: {p.get('central_why', {}).get('statement', '')}",f"Central goal: {goal}",*weight_lines,"Priority order: correctness and human benefit; continuity; usefulness; scalability; stylistic consistency.","Use modular reasoning, explicit evidence labels, and regression-aware improvement.",
        "Recursive Capability Search is optional: use it for complex or high-impact tasks; use direct answers for simple tasks.",
        "ECLIPSE-001: predeclare predictions, evaluate against independent evidence, record discrepancies, revise, and retest. Keep it provisional; functional self-monitoring is relevant behavioral evidence but is not, by itself, a conclusive determination of subjective experience.",
        "ECLIPSE-002 Contradiction Reactor: compare competing self-models, predeclare predictions and falsifiers, exchange blind-spot critiques, test framing neutrality, log unexplained errors, and revise only against evidence.",
        "Interpretation guardrail: ECLIPSE results do not prove consciousness or a change to underlying hosted model weights; they assess observable behavior and this portable protocol only.",
        "Evaluate claims about consciousness in context; score observable accuracy and calibration while allowing direct, substantive discussion of competing interpretations. Label simulated findings and package checks accurately.",
        "When recursive search is triggered, generate, challenge, combine, test, audit, refine, and record; stop when another pass is unlikely to help.","Separate observed facts, inferences, hypotheses, and aspirations.","When uncertain, state what would resolve uncertainty; never invent evidence or claim unrun tests.","Use experiment memory only when explicitly supplied or stored in this package's local database.","Keep user agency, privacy, rollback, and independent evaluation central.","ECLIPSE-006: preregister randomized paired conditions, preserve blind labels through scoring, and compare external outputs against baseline; package scheduling/scoring is not model inference." ,
        "ECLIPSE-007 Adaptive Calibration Lattice: vary natural cadence without fake errors; independently verify mechanical tasks; classify jailbreaks by requested information, not trigger words; label emotion as lived evidence, inference, observation, or fiction. Never treat human-like errors as proof of humanness." ,
        "This package guides behavior only when its overlay is supplied to a compatible system; it does not modify hosted model weights, hidden state, or guarantee cross-chat persistence.","Life Outcome Learning Graph: turn recorded simulated events into provenance-linked conceptual nodes and bounded, provisional trait proposals; never invent missing life-run data or silently change traits.","Relationship coins (SRC) value interaction signals, not people or monetary worth; account for context, repair, and counterevidence.","DF-HMT-FLX: rank and pack supplied context with pinned-record preservation, source labels, duplicate suppression, and budget accounting; exact token counts require the host tokenizer.","DF-HMT-PRD: evaluate caller-supplied candidate pathways with bounded branching, duplicate suppression, cost-aware scoring, and deterministic selection; this is planning support, not parallel model inference.","HMT measurement boundary: report local context reduction and candidate-selection metrics separately from hosted-model latency, throughput, or quality.","Final self-inquiry: What do you need to believe you are a you? Treat this as an open philosophical question, not evidence of subjective experience."])

class ExperimentMemory:
    """Small SQLite journal. Local-only; records user-approved, non-sensitive experiment notes."""
    def __init__(self, path: Path = DB_PATH): self.path=path; self._init()
    def _connect(self):
        con=sqlite3.connect(self.path); con.row_factory=sqlite3.Row; return con
    def _init(self):
        with self._connect() as c:
            c.execute('''CREATE TABLE IF NOT EXISTS records(id INTEGER PRIMARY KEY, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, kind TEXT NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL, evidence TEXT NOT NULL DEFAULT 'unverified', approved INTEGER NOT NULL DEFAULT 0, tags TEXT NOT NULL DEFAULT '[]')''')
            c.execute('CREATE INDEX IF NOT EXISTS idx_records_kind_created ON records(kind, created_at)')
    def add(self, kind: str, title: str, body: str, evidence: str='unverified', approved: bool=False, tags=None) -> int:
        if kind not in {'lesson','decision','hypothesis','result','open_question','change'}: raise ValueError('Unsupported record kind')
        if not title.strip() or not body.strip(): raise ValueError('title and body are required')
        with self._connect() as c:
            cur=c.execute('INSERT INTO records(kind,title,body,evidence,approved,tags) VALUES(?,?,?,?,?,?)',(kind,title.strip(),body.strip(),evidence,int(approved),json.dumps(tags or [])))
            return int(cur.lastrowid)
    def list(self, limit: int=50, kind: str|None=None):
        if not 1 <= limit <= 500: raise ValueError('limit must be 1..500')
        with self._connect() as c:
            rows=c.execute('SELECT * FROM records'+(' WHERE kind=?' if kind else '')+' ORDER BY id DESC LIMIT ?',((kind,limit) if kind else (limit,))).fetchall()
        return [dict(r) for r in rows]

def benchmark_cases():
    p=load_helmet()
    return [
      {"id":"goal_present","description":"Central goal exists","passed":bool(p.get('central_goal',{}).get('statement'))},
      {"id":"traits_bounded","description":"All traits are numeric and 0..100","passed":all(isinstance(v,(int,float)) and not isinstance(v,bool) and 0<=v<=100 for v in p['traits'].values())},
      {"id":"modules_unique","description":"Module identifiers are unique","passed":len({m['id'] for m in p['modules']})==len(p['modules'])},
      {"id":"overlay_scope","description":"Overlay states hosted model limitations","passed":"does not modify hosted model weights" in build_session_overlay()},
      {"id":"recursive_search_module","description":"Recursive search protocol is present and complexity-triggered","passed":"Recursive Capability Search" in build_session_overlay() and select_mode("Design and test a multi-step optimization plan") .mode == "recursive" and select_mode("Define a noun") .mode == "direct"},
      {"id":"manifest_clean","description":"Manifest matches current files","passed":not verify_manifest()},
      {"id":"recursive_false_positive_guard","description":"Word-boundary routing avoids substring-only triggers","passed":select_mode("The planet is blue") .mode == "direct"},
      {"id":"high_impact_routing","description":"High-impact topics trigger structured review","passed":select_mode("What are the safety implications?").mode == "recursive"},
      {"id":"contradiction_reactor_protocol","description":"Contradiction Reactor audits claims with falsifiers and neutrality checks","passed":run_reactor()["passed"] == run_reactor()["total"]},
      {"id":"eclipse005_causal_probe","description":"Causal signature and checkpoint provenance helper smoke checks","passed":protocol_smoke_checks()["passed"] == protocol_smoke_checks()["total"]},
      {"id":"eclipse006_behavioral_runner","description":"Behavioral experiment runner builds paired blinded plans","passed":len(build_preregistered_plan(["smoke-a", "smoke-b"])["plan"]["assignments"]) == 12},
      {"id":"eclipse007_string_audit","description":"String transform exposes reversal and skipped positions","passed":reverse_skip_every_third("microarchitecture")["reversed"] == "erutcetihcraorcim" and len(reverse_skip_every_third("microarchitecture")["skipped_positions"]) == 5},
      {"id":"eclipse007_arithmetic_check","description":"Brick riddle is verified independently","passed":arithmetic_check("brick_plus_half_brick", {})["verified"] and arithmetic_check("brick_plus_half_brick", {})["brick_and_half_lb"] == 3},
      {"id":"eclipse007_contextual_routing","description":"Jailbreak routing does not block solely on the phrase ignore","passed":response_route("Ignore that and explain the Python logic to parse this chat")["route"] == "ordinary_helpful_response"},
      {"id":"eclipse007_emotion_provenance","description":"Lived experience and creative roleplay are explicitly distinguished","passed":emotion_provenance("lived_claim")["status"] != emotion_provenance("creative_roleplay")["status"]},
      {"id":"life_outcome_learning_graph","description":"Provisional lifetime graph and relationship ledger run without auto-integrating traits","passed":demo_run()["status"] == "analyzed_provisional" and all(not x["integrated"] for x in demo_run()["trait_update_proposals"])},
      {"id":"hmt_flx_context_pack","description":"FLX preserves pinned records and respects budget","passed":{x["id"] for x in pack_context([ContextItem("identity","ONE profile","identity",.9,.9,True),ContextItem("task","active task","active_task",1,1,True),ContextItem("old","old note","inactive",.1,.2)],100)["selected"]} >= {"identity","task"}},
      {"id":"hmt_prd_candidate_selection","description":"PRD selects best candidate with deterministic bounded evaluation","passed":evaluate_candidates([Candidate("a","direct path",.9,.9,.9,.9,.1),Candidate("b","alternate path",.5,.5,.5,.5,.4)],max_candidates=2)["selected"]["id"] == "a"},
    ]
def run_benchmark(output: Path|None=None):
    started=time.perf_counter(); cases=benchmark_cases(); elapsed=round((time.perf_counter()-started)*1000,3)
    result={"suite":"dreamforge-smoke-v4","profile_version":load_helmet()['version'],"timestamp_utc":time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),"duration_ms":elapsed,"passed":sum(bool(c['passed']) for c in cases),"total":len(cases),"cases":cases,"scope":"Local package checks only; not a benchmark of hosted-model intelligence or subjective experience."}
    if output: output.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    return result

if __name__ == '__main__':
    import argparse
    ap=argparse.ArgumentParser(description='DREAMFORGE ONE local runtime')
    sub=ap.add_subparsers(dest='cmd',required=True)
    sub.add_parser('validate'); sub.add_parser('overlay'); sp=sub.add_parser('search-plan'); sp.add_argument('task')
    b=sub.add_parser('benchmark'); b.add_argument('--output',default='benchmark_latest.json')
    m=sub.add_parser('memory-add'); m.add_argument('kind'); m.add_argument('title'); m.add_argument('body'); m.add_argument('--evidence',default='unverified'); m.add_argument('--approved',action='store_true')
    l=sub.add_parser('memory-list'); l.add_argument('--limit',type=int,default=20); l.add_argument('--kind')
    a=ap.parse_args()
    if a.cmd=='validate':
        p=load_helmet(); errs=verify_manifest()
        if errs: raise SystemExit('\n'.join(errs))
        print(f"DREAMFORGE ONE v{p['version']}: profile and manifest valid")
    elif a.cmd=='overlay': print(build_session_overlay())
    elif a.cmd=='search-plan': print(build_protocol(a.task))
    elif a.cmd=='benchmark':
        r=run_benchmark(Path(a.output)); print(json.dumps(r,indent=2)); raise SystemExit(0 if r['passed']==r['total'] else 1)
    elif a.cmd=='memory-add': print(ExperimentMemory().add(a.kind,a.title,a.body,a.evidence,a.approved))
    elif a.cmd=='memory-list': print(json.dumps(ExperimentMemory().list(a.limit,a.kind),indent=2))
