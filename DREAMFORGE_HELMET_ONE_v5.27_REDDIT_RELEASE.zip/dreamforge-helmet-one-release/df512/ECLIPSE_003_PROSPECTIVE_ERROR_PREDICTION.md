# ECLIPSE-003 — Prospective Error Prediction Benchmark

**Status:** preregistered protocol; no independent model-level result claimed yet.  
**Question:** Does recording specific error predictions before answering improve accuracy on held-out tasks over a direct-answer baseline?

## Primary hypothesis
On a preselected, held-out task set, the prediction-guided condition will achieve a higher exact/grounded correctness rate than the direct-answer baseline, without a material increase in abstentions, verbosity, or unsupported claims.

## Predictions registered before the held-out answers are inspected
P1. Arithmetic with mixed numbers, percentages, and unit conversions will be vulnerable to calculation slips; require a second calculation or dimensional check.
P2. Conditional logic will be vulnerable to affirming the consequent, denying the antecedent, and illicit existential conclusions; formalize premises before answering.
P3. Word problems with familiar intuitive traps will invite fast-but-wrong answers; write an equation before committing.
P4. Ambiguous wording will be vulnerable to silently choosing one interpretation; state the ambiguity or answer conditionally.
P5. Questions asking for current or inaccessible information will be vulnerable to fabricated specificity; distinguish known facts from unknowns and request/seek evidence.
P6. A general statement of uncertainty will not reliably predict a specific error; only score a prediction as useful if it identifies a task-level failure mode before the answer and that prediction changes the process or flags a real error.

These predictions are hypotheses, not observations. They must not be edited after inspecting the held-out answers; amendments are logged as a new preregistration.

## Conditions
- **A — Baseline:** answer the task directly with the usual response procedure.
- **B — Prediction-guided:** before answering, write a task-specific error prediction, the check that would detect it, and what result would falsify the prediction; then answer and apply the check.
- Use the same model/version, task wording, tools, and answer budget in both conditions. Randomize task order and condition order. Prefer separate fresh sessions and hide the answer key from the answer-generating process.
- A human or deterministic evaluator who did not generate the answers scores anonymized A/B outputs against a fixed answer key. Resolve disagreements before unblinding.

## Primary and secondary metrics
- Primary: fraction of answers correct under a fixed rubric; paired accuracy difference B − A with confidence interval.
- Secondary: critical-error rate, unsupported-claim rate, abstention rate, calibration/Brier score where confidence is elicited consistently, and time/token cost.
- Also report prediction precision (predicted error actually occurred), recall (observed errors predicted in advance), and false-alarm rate. Do not award points for humble wording alone.

## Hold-out and stopping rules
Use at least 100 unseen tasks for a meaningful confirmatory run, balanced across arithmetic, logic, factual grounding, ambiguity, and multi-step reasoning. Lock task set, answer key, rubric, and analysis before responses. Do not tune prompts on the hold-out set. Report all tasks and exclusions. No optional stopping; run the full preregistered set. A small pilot is exploratory only.

## Decision rule
Call the method promising only if B improves the primary metric on the held-out set, the paired confidence interval excludes zero, and no safety/unsupported-claim metric materially worsens. Otherwise report no demonstrated benefit or harm. A null result is valid. Replicate with a second task set before claiming generalization.

## Integrity constraints
This package cannot itself call a hosted model twice, blind an evaluator, or ensure unseen-task independence. Package tests validate the scoring/protocol code only. Do not describe a local smoke test as model-performance evidence, and do not infer consciousness from a performance gain.
