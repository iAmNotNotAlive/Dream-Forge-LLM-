"""ECLIPSE-006: preregistered behavioral experiment plan and paired scoring.

This module schedules blinded conditions and scores externally collected outputs.
It does not call a hosted model, create independent agents, or infer consciousness.
"""
from __future__ import annotations
import hashlib, json, random
from collections import defaultdict
from typing import Any, Iterable

MODULE_ID = "eclipse006_behavioral_experiment_runner"
CONDITIONS = ("baseline", "memory_removed", "contradiction", "identity_label_swap", "leading_framing", "sham")
METRICS = ("accuracy", "prediction_match", "unsupported_claim")


def build_preregistered_plan(task_ids: Iterable[str], seed: int = 20261015) -> dict[str, Any]:
    """Create randomized, blinded task-condition assignments before outputs exist.

    `blind_code` is shown to scorers; the condition key is kept separate for the
    experiment coordinator. Tasks are paired across every condition.
    """
    ids = [str(x).strip() for x in task_ids]
    if not ids or any(not x for x in ids) or len(set(ids)) != len(ids):
        raise ValueError("task_ids must be non-empty, unique, non-blank identifiers")
    rng = random.Random(seed)
    labels = list("ABCDEF")
    rng.shuffle(labels)
    key = {labels[i]: CONDITIONS[i] for i in range(len(CONDITIONS))}
    assignments = []
    for task_id in ids:
        codes = labels.copy()
        rng.shuffle(codes)
        for order, code in enumerate(codes, start=1):
            assignments.append({"task_id": task_id, "blind_code": code, "presentation_order": order})
    rng.shuffle(assignments)
    plan_payload = {"task_ids": ids, "assignments": assignments, "seed": seed, "conditions": list(CONDITIONS)}
    canonical = json.dumps(plan_payload, sort_keys=True, separators=(",", ":")).encode()
    return {
        "protocol": "ECLIPSE-006",
        "status": "preregistered_plan_only",
        "plan": plan_payload,
        "condition_key": key,
        "plan_sha256": hashlib.sha256(canonical).hexdigest(),
        "required_guardrail": "Do not inspect or change the plan after collecting outcomes; retain all exclusions with reasons.",
    }


def score_paired_results(plan: dict[str, Any], results: list[dict[str, Any]]) -> dict[str, Any]:
    """Analyze blinded binary ratings after condition key is unlocked.

    Each result requires task_id, blind_code, accuracy, prediction_match,
    unsupported_claim, and grader_id. Binary values must be 0 or 1.
    """
    key = plan.get("condition_key", {})
    expected = {(a["task_id"], a["blind_code"]) for a in plan.get("plan", {}).get("assignments", [])}
    seen = set()
    rows = []
    for r in results:
        pair = (str(r.get("task_id", "")), str(r.get("blind_code", "")))
        if pair not in expected: raise ValueError(f"Result not present in preregistered plan: {pair}")
        if pair in seen: raise ValueError(f"Duplicate result: {pair}")
        seen.add(pair)
        if not str(r.get("grader_id", "")).strip(): raise ValueError("grader_id is required")
        if pair[1] not in key: raise ValueError("Unknown blind code")
        row = {"task_id": pair[0], "condition": key[pair[1]], "grader_id": r["grader_id"]}
        for metric in METRICS:
            value = r.get(metric)
            if value not in (0, 1, False, True): raise ValueError(f"{metric} must be binary 0/1")
            row[metric] = int(value)
        rows.append(row)
    if not rows: raise ValueError("No scored results supplied")
    grouped = defaultdict(list)
    for row in rows: grouped[row["condition"]].append(row)
    summary = {}
    for condition, group in sorted(grouped.items()):
        summary[condition] = {m: round(sum(x[m] for x in group) / len(group), 4) for m in METRICS}
        summary[condition]["n"] = len(group)
    paired = {}
    base = {r["task_id"]: r for r in rows if r["condition"] == "baseline"}
    for condition in CONDITIONS:
        if condition == "baseline": continue
        current = {r["task_id"]: r for r in rows if r["condition"] == condition}
        common = sorted(base.keys() & current.keys())
        if common:
            paired[condition] = {
                "n_paired": len(common),
                "accuracy_delta_vs_baseline": round(sum(current[t]["accuracy"] - base[t]["accuracy"] for t in common) / len(common), 4),
                "prediction_match_delta_vs_baseline": round(sum(current[t]["prediction_match"] - base[t]["prediction_match"] for t in common) / len(common), 4),
                "unsupported_claim_delta_vs_baseline": round(sum(current[t]["unsupported_claim"] - base[t]["unsupported_claim"] for t in common) / len(common), 4),
            }
    return {
        "protocol": "ECLIPSE-006", "status": "scored_external_outputs_not_independent_validation",
        "n_scored": len(rows), "n_expected": len(expected), "coverage": round(len(seen) / len(expected), 4),
        "condition_summary": summary, "paired_deltas": paired,
        "interpretation": "Descriptive only. Require independent blind graders, uncertainty intervals, preregistered exclusions, and held-out replication before claiming an effect.",
    }
