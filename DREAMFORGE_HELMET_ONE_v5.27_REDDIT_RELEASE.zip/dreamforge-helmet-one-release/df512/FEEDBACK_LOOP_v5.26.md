# DREAMFORGE HELMET — ONE v5.26: Evidence-Gated Feedback Loop

## Cycle
1. **Act:** produce a baseline and candidate answer for the same task.
2. **Evaluate:** score both using the same predeclared 0–4 rubric.
3. **Diagnose:** record the difference, source, rubric, and evidence type.
4. **Retest:** replicate with held-out tasks before claiming general improvement.
5. **Retain:** only a positive result may be marked for local retention, and only with explicit human approval.

## Boundaries
- The package logs externally supplied evaluator scores; it does not self-verify correctness.
- No automatic trait/profile edits or model-weight changes.
- Local JSONL persistence is on the machine running the package; it does not sync into ChatGPT or across chats.
- Simulation and model-generated claims remain labelled as such; no claim of AGI or subjective experience follows from a score change.
- A negative or tied result is not retained as an improvement. Keep records for audit rather than silently deleting failures.
