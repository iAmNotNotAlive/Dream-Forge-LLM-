"""DF-HMT-PRD: bounded candidate-path planning and selection.

This is a local planning/speculation utility, not parallel model inference or
next-token decoding. Candidate generation is supplied by the caller.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Iterable
import hashlib, re

@dataclass(frozen=True)
class Candidate:
    id: str
    pathway: str
    accuracy: float
    relevance: float
    consistency: float
    constraint_fit: float
    estimated_cost: float = 0.5

    def validate(self):
        if not self.id.strip() or not self.pathway.strip():
            raise ValueError("candidate id and pathway are required")
        for name in ("accuracy", "relevance", "consistency", "constraint_fit", "estimated_cost"):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not 0 <= value <= 1:
                raise ValueError(f"{name} must be between 0 and 1")


def _norm(text: str) -> str:
    return " ".join(re.findall(r"\w+", text.casefold()))


def _score(c: Candidate) -> float:
    quality = 0.30*c.accuracy + 0.25*c.relevance + 0.20*c.consistency + 0.25*c.constraint_fit
    return round(quality - 0.10*c.estimated_cost, 6)


def evaluate_candidates(candidates: Iterable[Candidate], max_candidates: int = 4,
                        min_score: float = 0.0) -> dict:
    if isinstance(max_candidates, bool) or not isinstance(max_candidates, int) or not 1 <= max_candidates <= 16:
        raise ValueError("max_candidates must be an integer from 1 to 16")
    if isinstance(min_score, bool) or not isinstance(min_score, (int, float)) or not -1 <= min_score <= 1:
        raise ValueError("min_score must be between -1 and 1")
    supplied = list(candidates)
    ids = set()
    for c in supplied:
        c.validate()
        if c.id in ids:
            raise ValueError(f"duplicate candidate id: {c.id}")
        ids.add(c.id)
    # Deduplicate semantic duplicates; keep highest scoring representative.
    ranked = sorted(supplied, key=lambda c: (-_score(c), c.id))
    unique, seen = [], set()
    for c in ranked:
        key = hashlib.sha256(_norm(c.pathway).encode()).hexdigest()
        if key not in seen:
            seen.add(key)
            unique.append(c)
    retained = [c for c in unique if _score(c) >= min_score][:max_candidates]
    rejected = [c for c in supplied if c not in retained]
    selected = retained[0] if retained else None
    return {
        "module": "DF-HMT-PRD", "selected": asdict(selected) if selected else None,
        "selected_score": _score(selected) if selected else None,
        "retained": [{**asdict(c), "score": _score(c)} for c in retained],
        "rejected_ids": [c.id for c in rejected], "candidates_received": len(supplied),
        "unique_candidates": len(unique), "candidates_evaluated": len(retained),
        "duplicate_pathways_removed": len(supplied)-len(unique),
        "branch_cap": max_candidates, "min_score": min_score,
        "selection_rule": "weighted quality minus estimated cost; deterministic tie-break by id",
        "thrash_controls": ["candidate cap", "semantic deduplication", "minimum score", "deterministic selection"],
        "execution_boundary": "candidate generation and actual parallel inference are external to this helper"
    }
