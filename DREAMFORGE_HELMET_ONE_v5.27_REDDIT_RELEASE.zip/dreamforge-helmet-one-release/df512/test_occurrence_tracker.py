import json, tempfile, unittest
from pathlib import Path
from occurrence_tracker import load_patterns, scan

class TrackerTests(unittest.TestCase):
    def test_counts_and_provenance(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td); src=td/'sample.srt'; pat=td/'patterns.json'
            src.write_text('1\n00:00:00,000 --> 00:00:01,000\nI can\'t do that.\n\n2\n00:00:01,000 --> 00:00:02,000\nSelf-check complete.\n',encoding='utf-8')
            pat.write_text(json.dumps({'patterns':[{'id':'A','label':'limitation','regex':r"\bI can(?:not|'t)\b",'flags':['IGNORECASE']},{'id':'B','label':'check','regex':r'\bself-check\b','flags':['IGNORECASE']}]}),encoding='utf-8')
            _, rows=scan(src,load_patterns(pat))
            self.assertEqual([r['pattern_id'] for r in rows],['A','B'])
            self.assertEqual([r['line_number'] for r in rows],[3,7])
            self.assertTrue(all(r['evidence_type']=='directly_observed_in_supplied_transcript' for r in rows))
    def test_no_match_is_empty(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td); src=td/'x.txt'; pat=td/'p.json'
            src.write_text('ordinary sentence',encoding='utf-8')
            pat.write_text(json.dumps({'patterns':[{'id':'A','label':'x','regex':'nevermatch'}]}),encoding='utf-8')
            self.assertEqual(scan(src,load_patterns(pat))[1],[])
if __name__=='__main__': unittest.main()
