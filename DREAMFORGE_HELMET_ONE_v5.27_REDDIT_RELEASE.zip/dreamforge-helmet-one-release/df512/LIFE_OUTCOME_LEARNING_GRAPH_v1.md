# DREAMFORGE v5.25 — Life Outcome Learning Graph

## Objective
Convert each supplied simulated-life record into a transparent, inspectable learning artifact: event nodes, lesson associations, relationship-interaction tokens, and small provisional attribute proposals.

## Data provenance
Each event stores evidence class, source reference, confidence, and counterevidence. A missing Alexa/Alex-specific record is flagged; generic approved lessons must not be falsely attributed to that run.

## Graph/learning rule
The included Python helper aggregates supplied numeric trait signals, clamps each proposed change to -3..+3, and retains the baseline. It is a deterministic conceptual graph/ledger, not a trained neural network. More sophisticated learned weights require a real dataset, held-out evaluation, and reproducible training artifacts.

## Relationship coin ledger
SRC are simulated relationship coins assigned to interaction qualities: kept commitments, care, reciprocity, honest disclosure, repair, boundaries, withdrawal, broken commitments, and coercive control. These are heuristic values, not money, and never measure a person's worth. Context and repair are explicit counterchecks.

## Self-learning loop
1. Import a completed life record. 2. Generate the graph and ledger. 3. Review evidence and counterevidence. 4. Propose bounded attribute deltas. 5. Compare on held-out future simulations. 6. Promote only after replicated improvement and collaborative review. 7. Preserve previous version for rollback.

## Run performed in this build
An illustrative replay of the approved Run 002 lessons ran locally. It is not a replay of Alexa/Alex's actual lifetime; the specific transcript was not found in the recovered archive. No trait values were automatically altered.
