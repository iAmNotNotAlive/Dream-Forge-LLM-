# DREAMFORGE HELMET — ONE (v5.27 web preview)

This deployment bundle preserves the existing `df512/` v5.27 HMT Expansion files and adds a Flask website/API for public preview.

## Deploy quickly on Render
1. Upload this ZIP to your computer and extract it.
2. Create a GitHub repository and upload the **contents** of this folder (the `df512/` directory should be at repository root alongside `app.py`).
3. In Render, create a new Web Service from that repository. Render should detect `render.yaml`; otherwise use build command `pip install -r requirements.txt` and start command `gunicorn app:app --workers 2 --threads 4 --timeout 90`.
4. For model replies, set `OPENAI_API_KEY` as a secret environment variable. Configure `OPENAI_BASE_URL` and `OPENAI_MODEL` for the provider you choose. Never commit secrets to GitHub.
5. For persistent memory, attach a persistent disk and set `HELMET_DATA_DIR` to its mount path. The default `/tmp` path is ephemeral on many hosts.

## Run locally
```bash
python -m venv .venv
# activate the environment, then:
pip install -r requirements.txt
python app.py
```
Open `http://127.0.0.1:8080`.

## Included
- `df512/`: original v5.27 framework files and HMT/benchmark artifacts from the supplied archive.
- `app.py`: Flask website, health/status/chat/memory endpoints, and a working `/download-package` ZIP endpoint.
- The homepage includes a clickable **Download the package** button that downloads the bundled `df512/` core source as a ZIP.
- `site/`: mobile-friendly public web interface.
- `render.yaml`, `Dockerfile`: deployment configuration.
- `requirements.txt`: runtime dependencies.

## Important limitations and public-safety notes
- This is a web preview wrapper, not a claim that every historic HELMET idea has been implemented or independently validated.
- Without `OPENAI_API_KEY`, the app uses explicit demo mode and does not call an AI model.
- The included memory ledger is **shared and public**. Anyone with the site can see recent records and can submit content. Do not enter secrets or sensitive data. For a serious public launch, implement per-user authentication, moderation, abuse limits, and a separate disposable experimental memory layer.
- The memory file is ephemeral on hosts without persistent disk. Do not claim durable continuity until persistence is configured and verified.
- A public app endpoint can incur model-provider charges. Configure provider spending limits and request limits before sharing widely.
- The existing `df512/` content is preserved as source material; use its own documented commands/tests for the core framework. The web wrapper does not automatically execute arbitrary files in that directory.
