# Reddit release quickstart — DREAMFORGE HELMET / ONE

## Run the core Python tests

Use Python 3.10+ (Python 3.11 is a good default). From the extracted project folder:

```bash
cd df512
python -m unittest -v test_helmet
```

The release preparation run completed **16 tests successfully** in `test_helmet.py`. This is a test result for that suite only; it is not a full security review or proof that every module works in every environment.

## Run the web preview locally

From the project root (the folder containing `app.py`):

```bash
python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

Then open `http://127.0.0.1:8080` in your browser. Without `OPENAI_API_KEY`, the interface intentionally uses demo mode and clearly says no language model was called. To use a model, configure an OpenAI-compatible chat-completions endpoint through environment variables; never put credentials in source code or a public repository.

## Important before public deployment

- The preview's memory ledger is shared across visitors and its recent records are publicly readable. **Do not enter secrets, personal data, or private conversations.**
- Public deployment has not had a production security review, rate-limit/load test, or full web endpoint test in the release environment.
- A configured model API can incur charges. Set provider spending limits before sharing a live instance.
- Durable memory requires a configured persistent disk; otherwise hosting restarts may erase it.
- This is a framework and web preview, not evidence of AI consciousness, subjective experience, or changes to underlying model weights.
- No explicit open-source license is included in this bundle. If you want others to reuse or redistribute the code, choose and add a license first.
