# Publish the website

1. Extract this ZIP.
2. Create a new GitHub repository (public if you want the source public).
3. Upload the files and folders inside this archive to the repository root. Do not upload only the outer folder as a nested folder.
4. In Render, choose New + → Web Service, connect the repository, and deploy. `render.yaml` contains the build/start configuration.
5. In Render Environment, set `OPENAI_API_KEY` if you want model-backed replies. Never put the key in source code or commit it.
6. For durable memory, configure a persistent disk and set `HELMET_DATA_DIR` to its mount path. Without that, many hosts can discard the memory file on restart/redeploy.

This public preview uses a shared memory ledger. Before advertising it widely, add rate limiting, moderation, abuse monitoring, and decide whether shared public memory is appropriate. Do not use it to store secrets or personal data.
